console.log("Hi Sulthan", "Doing Something New");
console.log("Hi Sulthan");

/*
console.log("Hi Sulthan");
console.log("Hi Sulthan");
// console.log("Hi Sulthan");
*/

console.log("Hi Sulthan");
