let number = 10;

switch (true) {
  case number > 0:
    console.log("This is a Positive Number");
    break;

  case number === 0:
    console.log("This is a Zero Number");
    break;

  case number < 0:
    console.log("This is a Negative Number");
    break;
}
