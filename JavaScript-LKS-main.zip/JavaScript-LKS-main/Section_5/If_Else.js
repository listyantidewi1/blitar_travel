// Conditional Statements

//  if(condition1){
//       statement
//    }
//    else if(condition2){
//        statement
//    }
//    else if(condition3){
//        statement
//    }
//    else {

//    }

let number = 0;

if(number > 0){
    console.log('This is positive number')
}