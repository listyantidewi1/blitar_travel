let number1 = 10;
let number2 = 2;

let maxValue;
if (number1 > number2) {
  maxValue = number1;
} else {
  maxValue = number2;
}

let max = number1 > number2 ? number1 : number2;

console.log(maxValue);
