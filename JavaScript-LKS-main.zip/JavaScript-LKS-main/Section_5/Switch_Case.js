// Switch Case
// COnditional Statement

let color = "red";

switch (color) {
  case "purple":
    console.log("This is Purple");
    break;

  case "white":
    console.log("This is White");
    break;

  case "red":
    console.log("This is Red");
    break;
}
