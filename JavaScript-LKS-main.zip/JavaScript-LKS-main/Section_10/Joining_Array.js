let numbers = [1, 2, 3, 4];
let arrayJoin = numbers.join(" ");
console.log(arrayJoin);

let message = "Hi My Name is Sulthan";
const arrayMessage = message.split(" ");
console.log(arrayMeesage.join("-"));
