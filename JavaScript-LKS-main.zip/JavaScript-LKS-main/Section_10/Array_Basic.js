let friends = ["Sulthan", "Rafif", "Hilal", "Afri", "Dimas"];

console.log(friends);
console.log(friends[1]);
console.log(friends[3]);
console.log(friends[5]);
console.log(friends[0]);

console.log(friends.length);
