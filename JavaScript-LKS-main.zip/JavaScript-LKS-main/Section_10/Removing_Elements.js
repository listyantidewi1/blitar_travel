const numbers = [1,2,3,4,5,6,7,8];

numbers.shift();
numbers.shift();

numbers.pop();
numbers.pop();

numbers.splice(2,3);

console.log(numbers);