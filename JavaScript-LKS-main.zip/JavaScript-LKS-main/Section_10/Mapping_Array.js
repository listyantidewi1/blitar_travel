let doctor = [
  { name: "Sulthan", age: 17 },
  { name: "Rafif", age: 18 },
  { name: "Hilal", age: 19 },
];

const docName = doctor.map((doc) => doc.age);
console.log(docName);
