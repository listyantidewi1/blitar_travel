const num1 = [1, 2, 3];
const num2 = [4, 5, 6, 7];

const num = num1.concat(num2);
console.log(num);

const angka = [1, 2, 3, 4, 5, 6, 7, 8, 9];
const potongArray = angka.slice;
console.log(potongArray);
