const numbers = [1, 2, 3, 2, 5, 6, 2, 8];

console.log(numbers.includes(6, 4));
console.log(numbers.indexOf(2));
console.log(numbers.lastIndexOf(2));

console.log(numbers);
