let num1 = 10;
let num2 = 5;

console.log(num1 + num2);
console.log(num1 - num2);
console.log(num1 * num2);

console.log(num1 / num2);

console.log(num1 ** num2);

console.log(num1 % num2);
