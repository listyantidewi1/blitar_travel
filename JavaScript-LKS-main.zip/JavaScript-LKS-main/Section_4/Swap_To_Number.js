// Swap to numbers

let apple = 10;
let orange = 20;

let temp = apple;
apple = orange;
orange = temp;

console.log(apple, orange);
