// > < >= <= === !==

let price = 2000;

console.log(price > 4000);
console.log(price >= 2000);
console.log(price < 1000);
console.log(price <= 5000);
console.log(price === 2000);
console.log(price !== 5000);
