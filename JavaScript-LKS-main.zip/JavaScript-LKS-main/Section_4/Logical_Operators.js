// Logical Operator
// and(&&), or(||), not(!)

let price = 10;
console.log(price > 5 && price < 15);

// true && true

console.log(price > 50 || price < 15);

console.log(!(price > 50));
