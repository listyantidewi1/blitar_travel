//let num1 = 10;
//let num2 = num1;

//console.log(num1, num2);

let num1 = 10;
let num2 = num1 + 5;
num1 += 5;
console.log(num2);

num1 = num1 - 5;
num1 -= 5;

num1 = num1 * 5;
num1 *= 5;

num1 = num1 + 1;
num1 += 1;
num1++;

num1 = num1 - 1;
num1 -= 1;
num1--;
