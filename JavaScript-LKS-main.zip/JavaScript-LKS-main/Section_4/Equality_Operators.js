let price = 10;

console.log(price === 10);
console.log(price !== 20);

console.log(price == "10");
console.log(price != 20);
