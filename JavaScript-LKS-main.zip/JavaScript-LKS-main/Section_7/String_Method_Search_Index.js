let message = 'Hi My name Is Hi Sulthan Sabilillah';
console.log(message);
console.log(message.search('Yo'));
console.log(message.indexOf('Nya'));
console.log(message.lastIndexOf('Hi'));