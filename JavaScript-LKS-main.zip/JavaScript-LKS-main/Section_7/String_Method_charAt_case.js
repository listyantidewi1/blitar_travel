let message = "Hi My name is Sulthan";
console.log(message);
console.log(message.charAt(2));
console.log(message.toUpperCase());
console.log(message.toLowerCase());
console.log(message.includes("Sulthan"));
console.log(message.startsWith("Aiyoo"));
console.log(message.endsWith("Sabilillah"));
