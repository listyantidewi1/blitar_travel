let message = 'ini Sulthan \\ "It\'s a nice blablu".\nHow are you? ';
console.log(message);
