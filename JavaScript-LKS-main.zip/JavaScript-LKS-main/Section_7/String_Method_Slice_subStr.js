let message = "Hi Nama ku adalah Sulthan";
console.log(message.slice(0, 4));
console.log(message.slice(3, 9));
console.log(message.slice(3));
console.log(message.slice());
console.log(message.slice(0));
console.log(message.slice(-9, -4));

console.log(message.substring(0, 4));
console.log(message.substr(0, 3));
