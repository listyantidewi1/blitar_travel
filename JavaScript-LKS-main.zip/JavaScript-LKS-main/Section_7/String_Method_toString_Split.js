let message = "Hi My name is Sulthan";
console.log(message.split(" "));
