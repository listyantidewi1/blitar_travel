let kota = "Malang";
console.log(kota);
console.log(typeof kota);
console.log(kota[2]);
console.log(kota.charAt(5));
