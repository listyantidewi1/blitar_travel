let message = "Hi Sulthan";
message = message + " how are you";
console.log(message);
