for (let index = 1; index <= 5; index++) {
  console.log("Hi Sulthan ", index);
}
for (let index = 5; index >= 1; index--) {
  console.log("Hi Sabilillah ", index);
}
