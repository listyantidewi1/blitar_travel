for (let index = 1; ; index++ ){
    console.log(index);
}