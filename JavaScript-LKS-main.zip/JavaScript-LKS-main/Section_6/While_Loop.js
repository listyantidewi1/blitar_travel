for (let index = 1; index <= 5; index++) {
  console.log("Hi Sulthan");
}

let index = 1;
while (index <= 5) {
  console.log("Hi Ssabilillah", index);
  index++;
}
