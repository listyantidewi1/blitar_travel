for (let Sulthan = 1; Sulthan <= 3; Sulthan++) {
  for (let Sabil = 1; Sabil <= 3; Sabil++) {
    console.log(Sulthan, Sabil);
  }
}
