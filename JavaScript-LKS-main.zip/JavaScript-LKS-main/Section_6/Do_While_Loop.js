let index = 100;
while (index <= 5) {
  console.log("Hi Sulthan", index);
}

let service = 100;
do {
  console.log("Hi Sabilillah", service);
  service++;
} while (service <= 5);

console.log(service);
