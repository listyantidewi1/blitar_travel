for (let index = 1; index <= 20; index++) {
  if (index === 10) {
    continue;
  }

  console.log(index);
}
