const addnumber = (num1, num2) => num1 + num2;

export default addnumber;
