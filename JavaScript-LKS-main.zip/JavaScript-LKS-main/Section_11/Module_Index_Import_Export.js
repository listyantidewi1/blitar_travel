import addnumber from "./Module_Main_Import_Export";

console.log(addnumber(10, 20));
