let friends = ["Sulthan", "Rafif", "Hilal", "Sulthan"];

console.log(friends);
console.log(friends[2]);
console.log(typeof friends);

console.log(friends.length);
