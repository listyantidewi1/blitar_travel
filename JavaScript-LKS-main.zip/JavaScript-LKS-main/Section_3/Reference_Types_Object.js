let name = "Sulthan";
let age = 17;
let hobby = "Gaming";

let user = {
  name: "Sulthan",
  age: "17",
  hobby: "Gaming",
};

console.log(user);
console.log(user.name);
console.log(user.hobby);

console.log(user["name"]);
console.log(user['age']);

