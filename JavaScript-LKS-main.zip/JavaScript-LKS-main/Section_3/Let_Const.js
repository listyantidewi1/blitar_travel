//variables

let price = 2000;

price = 4000;

const name = "Sulthan";
name = "Sabilillah";

console.log(price, name);
