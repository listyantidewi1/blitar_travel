function showMyName(name) {
  console.log("My name is " + name);
  // console.log("My name is Sulthan");
}
showMyName("Sulthan");
showMyName("Rafif");
showMyName("Hilal");

// let num1 = 30;
// let num2 = 20;
// let sum = num1 + num2;
// console.log(sum);

function calcSum(num1, num2) {
  const sum = num1 + num2;
  return sum;
}

const result = calcSum(30, 30);
console.log(result);
