let name = "Cristal Maiden";
console.log(`My name is ${name} `);

console.log(`${30 + 20}`);

let message = "My name is \nSulthan Sabilillah";
console.log(message);
