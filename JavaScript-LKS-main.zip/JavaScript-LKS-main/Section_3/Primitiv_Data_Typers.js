let name = "Sulthan";
console.log(typeof name);

let age = 17;
console.log(typeof age);

let isMarried = false;
console.log(typeof isMarried);

let colors = undefined;
console.log(typeof colors);

let selectColors = null;
console.log(typeof selectColors);
