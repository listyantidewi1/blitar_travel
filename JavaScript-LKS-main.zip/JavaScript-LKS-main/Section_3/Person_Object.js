let person = {
  name: "Sulthan",
  age: "17",
  notMarried: false,

  homeAddress: {
    long: 44.55,
    lat: 33.44,
  },
  friends: ["Sulthan", "Rafif", "Hilal"],
};

console.log(person);
console.log(person.notMarried);
console.log(person.homeAddress.long);
console.log(person.friends[2]);
