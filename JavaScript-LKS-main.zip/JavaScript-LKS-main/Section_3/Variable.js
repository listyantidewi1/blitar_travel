// variables

var name = "Sulthan";
console.log(name);
