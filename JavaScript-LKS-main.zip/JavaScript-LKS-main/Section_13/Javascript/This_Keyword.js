const Mango = {
  color: "Pink",
  price: 120,
  weight: 120,
  about: function () {
    // return "This mango price is " + this.price + " USD";
    return "This mengaooo Color is ${this.color} Name";
  },
};
console.log(Mango.about());
