// var a = function name(n) {
//   return n;
// };
// console.log(a("Mudah Belajar"));

// let fruit = (f) => {
//   return f;
// };
// console.log(fruit("Apple"));

// let fruit = (f) => f;
// console.log("Mango");

// let multiply = (m) => m * m * m;
// console.log(multiply(3));

let add = (m, n) => m * n;
console.log(add(3, 2));
