function foo() {
  for (var i = 0; i < 4; i++) {
    console.log("Easy Learning");
  }
  console.log(i);
}
foo();
