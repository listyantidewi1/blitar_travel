import React from "react";

export default class about extends React.Component {
  render() {
    return (
      <div>
        <h1>This is About Component</h1>
      </div>
    );
  }
}
