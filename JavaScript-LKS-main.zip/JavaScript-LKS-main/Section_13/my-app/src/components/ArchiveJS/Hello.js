import react from "react";

function Hello(props) {
  return (
    <h1>
      I Love {props.name} and weight is {props.weight}
    </h1>
  );
}

export default Hello;
