import React from "react";

export default class blog extends React.Component {
  render() {
    return (
      <div>
        <h1>This is Blog Profile</h1>
      </div>
    );
  }
}
