import React from "react";

export default class profile extends React.Component {
  render() {
    return (
      <div>
        <h1>This is Profile Component</h1>
      </div>
    );
  }
}
