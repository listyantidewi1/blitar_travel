import React from "react";

export default class contact extends React.Component {
  render() {
    return (
      <div>
        <h1>This is contact Component</h1>
      </div>
    );
  }
}
