console.log(Math.PI);
console.log(Math.random());
console.log(Math.round(1.9));
