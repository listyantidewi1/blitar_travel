let name = "Sulthan";
let age = 17;
let hobby = "Listening Music";

const user = {
  name: "Sulthan",
  age: 17,
  hobby: "Listening Music",
};

console.log(user);

console.log(user.name);

console.log(user["hobby"]);
console.log(user["age"]);
