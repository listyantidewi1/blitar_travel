const user = {
  name: "Sulthan",
  age: 17,
};

const jsonData = JSON.stringify(user);
console.log(JSON.parse(jsonData));
console.log(jsonData);
